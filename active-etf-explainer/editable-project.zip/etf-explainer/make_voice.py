import json, subprocess
from pathlib import Path
import numpy as np
import sherpa_onnx
import soundfile as sf

ROOT=Path(__file__).resolve().parent
MODEL=Path('/workspace/video-models/vits-melo-tts-zh_en')
config=sherpa_onnx.OfflineTtsConfig(
 model=sherpa_onnx.OfflineTtsModelConfig(
  vits=sherpa_onnx.OfflineTtsVitsModelConfig(
   model=str(MODEL/'model.onnx'),lexicon=str(MODEL/'lexicon.txt'),
   tokens=str(MODEL/'tokens.txt')),
  num_threads=3,debug=False,provider='cpu'),
 rule_fsts=','.join(str(MODEL/x) for x in ['date.fst','number.fst','phone.fst','new_heteronym.fst']),
 max_num_sentences=1)
assert config.validate()
tts=sherpa_onnx.OfflineTts(config)
scenes=json.loads((ROOT/'scenes.json').read_text())
chunks=[]; cursor=0; captions=[]
sr=tts.sample_rate
def silence(seconds):
 global cursor
 chunks.append(np.zeros(round(sr*seconds),dtype=np.float32));cursor+=seconds
silence(.6)
for i,scene in enumerate(scenes):
 scene['start']=round(cursor-.3 if i else 0,3)
 for text in scene['speech']:
  spoken=text.replace('ETF','E T F')
  audio=tts.generate(spoken,sid=0,speed=1.25)
  samples=np.array(audio.samples,dtype=np.float32)
  duration=len(samples)/sr
  captions.append({'start':round(cursor,3),'end':round(cursor+duration,3),'text':text})
  chunks.append(samples);cursor+=duration
  silence(.17)
 silence(.5)
 print(i+1,round(cursor,2),flush=True)
silence(5.3)
sf.write(ROOT/'narration-fast.wav',np.concatenate(chunks),sr)
subprocess.run(['ffmpeg','-v','error','-i',str(ROOT/'narration-fast.wav'),'-af','atempo=0.9','-y',str(ROOT/'narration.wav')],check=True)
cursor /= .9
for scene in scenes: scene['start']=round(scene['start']/.9,3)
for c in captions:
 c['start']=round(c['start']/.9,3);c['end']=round(c['end']/.9,3)
(ROOT/'timing.json').write_text(json.dumps({'duration':round(cursor,3),'scenes':scenes,'captions':captions},ensure_ascii=False,indent=2))
print('DURATION',cursor,flush=True)
