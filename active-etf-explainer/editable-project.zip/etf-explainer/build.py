import json, html, math, wave
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent
data=json.loads((P/'timing.json').read_text()); D=data['duration']
def text(x,y,t,size=40,color='#242620',weight=500):
 return f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{weight}" text-anchor="middle">{html.escape(t)}</text>'
def line(x1,y1,x2,y2):return f'<path d="M{x1} {y1}L{x2} {y2}" stroke="#9A4C12" stroke-width="4" fill="none"/>'
def box(x,y,w,h,fill='#E5DDCF'):return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="{fill}"/>'
def art(kind):
 a=''
 if kind=='launch':
  a=text(450,285,'18',270,'#9A4C12',900)+text(450,390,'只主动ETF',54)+line(140,450,760,450)+text(450,510,'10 / 23 · 周五',40)
 elif kind=='choice':
  a=box(90,70,720,180)+text(450,178,'产品创新',64)+line(450,270,450,330)+box(90,350,720,170,'#242620')+text(450,452,'投资方式的选择',58,'#F4EFE5')
 elif kind=='formula':
  a=box(80,50,740,155)+text(450,146,'主动管理',64)+text(450,273,'＋',65,'#9A4C12')+box(80,310,740,155,'#242620')+text(450,408,'ETF交易形式',61,'#F4EFE5')+text(450,535,'能力由策略决定',36,'#9A4C12')
 elif kind=='trade':
  a=line(90,270,810,270)
  for x,t in [(120,'开盘'),(450,'盘中'),(780,'收盘')]:
   a+=f'<circle cx="{x}" cy="270" r="15" fill="#9A4C12"/>'+text(x,345,t,40)
  a+=text(450,150,'交易时段内买卖',59)+box(135,415,630,100)+text(450,480,'可用资金 ≠ 可取资金',40)
 elif kind=='disclose':
  a=box(230,40,460,420)+box(180,90,460,420,'#FFFFFF')
  for i,w in enumerate([315,240,300,185]):a+=box(230,165+i*65,w,12,'#D8A453' if i==0 else '#E5DDCF')
  a+=text(450,570,'看清披露范围与频率',43,'#9A4C12')
 elif kind=='cost':
  for i,(t,n) in enumerate([('管理费','01'),('交易佣金','02'),('买卖价差','03')]):
   y=55+i*155;a+=box(85,y,730,125,'#242620' if i==1 else '#E5DDCF')+text(175,y+83,n,42,'#F4EFE5' if i==1 else '#9A4C12')+text(485,y+83,t,54,'#F4EFE5' if i==1 else '#242620')
 elif kind=='strategy':
  for i,(label,sub) in enumerate([('流动性','能否顺畅交易'),('换手率','交易频率多高'),('投资风格','策略是否适合')]):
   y=85+165*i;a+=text(240,y,label,51,'#9A4C12')+text(600,y,sub,39)+line(90,y+50,810,y+50)
 elif kind=='industry':
  a=text(450,135,'投研能力',69)+text(450,223,'×',55,'#9A4C12')+text(450,310,'ETF运营',69)+line(160,365,740,365)+text(450,445,'销售 · 交易 · 做市',48)+text(450,520,'受益程度取决于业务与竞争',32,'#9A4C12')
 elif kind=='risk1':
  a=text(450,245,'≠',220,'#9A4C12')+text(450,95,'主动管理',61)+text(450,365,'必然跑赢',61)+box(100,435,700,115,'#242620')+text(450,510,'也可能亏损',53,'#F4EFE5')
 elif kind=='premium':
  a=box(90,80,330,280)+box(480,80,330,280,'#242620')+text(255,185,'成交价',49)+text(255,285,'场内价格',35,'#9A4C12')+text(645,185,'参考净值',49,'#F4EFE5')+text(645,285,'价值参照',35,'#F4EFE5')+text(450,450,'两者之间可能有偏离',48)+text(450,525,'关注折溢价 · 注意流动性',36,'#9A4C12')
 elif kind=='small':
  a=text(450,150,'单笔最低佣金',64)+text(450,240,'÷',70,'#9A4C12')+text(450,335,'交易金额',64)+line(180,390,720,390)+text(450,475,'金额越小，越要留意成本占比',38)
 else:
  a=f'<circle cx="450" cy="245" r="165" stroke="#9A4C12" stroke-width="4" fill="none"/>'+text(450,270,'选择',95,'#9A4C12',900)+text(450,510,'读文件 · 看策略 · 算成本',42)
 return '<svg viewBox="0 0 900 610" width="900" height="610" aria-label="'+kind+'机制示意">'+a+'</svg>'
scenes=[]; anim=[]
for i,s in enumerate(data['scenes']):
 title=html.escape(s['title']).replace('\n','<br>')
 scenes.append(f'''<section id="s{i}" class="scene" style="z-index:{i+1};opacity:{1 if i==0 else 0}"><div class="scene-content"><div class="kicker enter">{html.escape(s['kicker'])}</div><h1 class="enter">{title}</h1><div class="accent enter">{html.escape(s['accent'])}</div><div class="art enter" data-layout-ignore>{art(s['kind'])}</div><p class="note enter">{html.escape(s['note'])}</p></div></section>''')
 st=s['start']; t=st+.2
 if i:
  anim.append(f'tl.to("#s{i-1}",{{opacity:0,duration:.5,ease:"power2.inOut"}},{st});tl.to("#s{i}",{{opacity:1,duration:.5,ease:"power2.inOut"}},{st});')
 for j,(selector,prop,ease) in enumerate([('.kicker','y:16','power2.out'),('h1','y:42','power3.out'),('.accent','x:25','sine.out'),('.art','scale:.96','power2.out'),('.note','y:12','sine.out')]):
  anim.append(f'tl.from("#s{i} {selector}",{{{prop},opacity:0,duration:.6,ease:"{ease}"}},{t+j*.13});')
 # Gentle finite internal movement, decorative only.
 anim.append(f'tl.fromTo("#s{i} .art svg",{{y:8}},{{y:-8,duration:3,ease:"sine.inOut",yoyo:true,repeat:1}},{t+1});')
captions=[]
def split_caption(t,maxlen=36):
 return [t]

srt=[]; idx=1
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
for c in data['captions']:
 parts=split_caption(c['text']); total=sum(len(p) for p in parts); st=c['start']
 for part in parts:
  end=st+(c['end']-c['start'])*len(part)/total
  captions.append(f'<div id="cap{idx}" class="caption clip" data-start="{st:.3f}" data-duration="{end-st:.3f}" data-track-index="3">{html.escape(part)}</div>')
  srt.append(f'{idx}\n{stamp(st)} --> {stamp(end)}\n{part}\n')
  st=end;idx+=1
page='''<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=1080,height=1920"><script src="node_modules/gsap/dist/gsap.min.js"></script><style>
@font-face{font-family:FilmHei;src:url('font-bold.otf');font-weight:900}@font-face{font-family:FilmHei;src:url('font-regular.otf');font-weight:400}
*{box-sizing:border-box}html,body{margin:0;width:1080px;height:1920px;overflow:hidden;background:#F4EFE5;color:#242620;font-family:FilmHei,sans-serif}#root{width:1080px;height:1920px;position:relative}.scene{position:absolute;inset:0;background:#F4EFE5;overflow:hidden}.scene-content{width:100%;height:100%;padding:130px 90px 430px;display:flex;flex-direction:column;gap:30px}.kicker{font-size:30px;letter-spacing:4px;color:#9A4C12;line-height:1.5}h1{font-size:104px;line-height:1.18;letter-spacing:-3px;font-weight:900;margin:0;min-height:246px}.accent{font-size:38px;line-height:1.5;color:#9A4C12;min-height:68px}.art{width:900px;height:610px;flex-shrink:0;font-family:FilmHei,sans-serif}.note{margin:0;font-size:30px;line-height:1.6;max-width:900px;min-height:87px;color:#514D44}.caption{position:absolute;top:1435px;left:90px;width:900px;min-height:130px;display:flex;align-items:center;justify-content:center;text-align:center;font-size:44px;line-height:1.45;z-index:100;color:#242620}.footer{position:absolute;left:90px;right:90px;top:1650px;z-index:110;border-top:2px solid #D8A453;padding-top:24px;display:flex;justify-content:space-between;font-size:28px;color:#514D44}.risk{position:absolute;z-index:110;left:90px;right:90px;top:1730px;font-size:30px;line-height:1.65;color:#514D44}.folio{font-variant-numeric:tabular-nums}
</style></head><body><div id="root" data-composition-id="main" data-start="0" data-duration="DURATION" data-width="1080" data-height="1920">SCENES CAPTIONS<div class="footer"><span>主动ETF · 机制与风险</span><span class="folio">#ETF / KNOW THE TOOL</span></div><div class="risk">主动管理不保证一定产生超额收益，投资有风险。<br>本片为知识介绍，不构成投资建议。</div><audio id="narration" data-start="0" data-duration="DURATION" data-track-index="5" src="narration.wav" data-volume="1"></audio><audio id="music" data-start="0" data-duration="DURATION" data-track-index="6" src="music.wav" data-volume="0.13"></audio></div><script>window.__timelines=window.__timelines||{};const tl=gsap.timeline({paused:true});ANIMS window.__timelines.main=tl;</script></body></html>'''
page=page.replace('DURATION',str(D)).replace('SCENES',''.join(scenes)).replace('CAPTIONS',''.join(captions)).replace('ANIMS','\n'.join(anim))
(P/'index.html').write_text(page)
(P/'subtitles.srt').write_text('\n'.join(srt))
(P/'旁白文案.txt').write_text('\n\n'.join(''.join(s['speech']) for s in data['scenes']))
# Original quiet sound bed: slow broken chords, no licensed external recording.
sr=24000;t=np.arange(round(D*sr))/sr;audio=np.zeros_like(t)
for beat in np.arange(0,D,1.5):
 chord=[130.81,164.81,196.0,261.63][int(beat/1.5)%4]
 u=t-beat;env=np.where(u>=0,np.exp(-np.maximum(u,0)/1.7)*(1-np.exp(-np.maximum(u,0)*12)),0)
 audio+=.1*env*(np.sin(2*np.pi*chord*t)+.2*np.sin(2*np.pi*chord*2*t))
audio*=np.minimum(1,t/2)*np.minimum(1,np.maximum(0,D-t)/3)
with wave.open(str(P/'music.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes((audio*32767).astype('<i2').tobytes())
print('Built',D,'seconds,',len(scenes),'scenes,',idx-1,'captions')
