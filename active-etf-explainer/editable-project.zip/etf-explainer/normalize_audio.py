import json, subprocess
from pathlib import Path

# Run after rendering, from this project directory. Preserve the render master.
p=Path('active-etf-final.mp4'); master=Path('render-master.mp4')
if p.exists():
 if master.exists(): raise RuntimeError('Preserve or move the existing render-master.mp4 before normalizing a new render')
 p.rename(master)
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(master),'-af','loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json','-vn','-f','null','-'],capture_output=True,text=True,check=True)
s=r.stderr;d,_=json.JSONDecoder().raw_decode(s[s.rindex('{'):]);Path('loudness-measured.json').write_text(json.dumps(d,indent=2))
f=f"loudnorm=I=-16:TP=-1.5:LRA=11:measured_I={d['input_i']}:measured_TP={d['input_tp']}:measured_LRA={d['input_lra']}:measured_thresh={d['input_thresh']}:offset={d['target_offset']}:linear=true:print_format=json"
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(master),'-c:v','copy','-af',f,'-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart',str(p)],capture_output=True,text=True,check=True)
Path('loudness-normalization.log').write_text(r.stderr)
print('Loudness normalized for mobile playback')
