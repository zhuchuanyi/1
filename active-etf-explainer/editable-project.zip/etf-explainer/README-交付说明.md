# 18只主动ETF来了

- 画幅：1080×1920，9:16；30fps；约112.83秒。
- 风格：米白纸面、墨黑黑体、琥珀重点；12镜头机制动态图解。
- 声音：本地MeloTTS中文女声；原创程序合成的低音量背景音。
- 字幕：24句，与逐句生成旁白的时间范围同步；不是人工逐字校对的转写。
- 新闻信息：18只、2026-10-23发行来自用户文案及日期补充，未独立核实，开场已注明来源及以正式公告为准。
- 精简处理：删去未经核实的规模、复合增速、具体产品分类、托管资格及确定性受益排序。将完整持仓、零费用、资金可用等绝对表述改为具体产品及交易规则说明。
- 风险提示全片保留，片尾有超过5秒阅读时间。

最终交付经过双遍响度归一化，目标为-16 LUFS、真峰值不超过-1.5 dBTP，视频流保持原编码。

## 文件

- `active-etf-final.mp4`：成片。
- `subtitles.srt`：配套字幕。
- `旁白文案.txt`：精简后的实际旁白。
- `index.html`：可编辑动画源文件。
- `scenes.json`：12镜头内容与旁白文本。
- `timing.json`：逐句旁白时间与镜头起点。
- `make_voice.py`：本地中文语音生成；模型来源 https://github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models ，原模型 https://github.com/myshell-ai/MeloTTS 。模型MIT许可证留在 `/workspace/video-models/vits-melo-tts-zh_en/LICENSE`。
- `build.py`：从时间表生成HTML、SRT与原创背景音乐。

## 再编辑与导出

使用现有隔离工作区，不需新建Git worktree。当前项目在仓库外，原仓库 `/workspace/1` 未修改。

```bash
cd /workspace/etf-explainer
# 修改 scenes.json 后才重新生成旁白（会覆盖旧音频和时间表）
/workspace/video-tools/bin/python make_voice.py
/workspace/video-tools/bin/python build.py
XDG_CACHE_HOME=/workspace/.cache HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npm run check
XDG_CACHE_HOME=/workspace/.cache HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npm run render -- --output active-etf-final.mp4 --quality high --fps 30 --workers 3
# 移走旧的 render-master.mp4 后，为新渲染版本归一化响度
/workspace/video-tools/bin/python normalize_audio.py
```

字幕每句显示对应整句语音时长。为了让手机用户读懂图解与字幕，镜头有刻意的静态阅读停留；检查器的 `dead_stretch` 提示属于此处设计。统一0.5秒交叉溶解转场中的短暂文字叠化属于转场效果。
