// Deterministic orthographic globe. CSS visual variables are driven by the paused master timeline.
function drawGlobalEarth(){
 const canvas=document.getElementById('global-earth');if(!canvas)return;const c=canvas.getContext('2d');
 const lon=Number(canvas.style.getPropertyValue('--earth-longitude')||-100),lat=25*Math.PI/180;
 const R=258,cx=820,cy=328,rad=Math.PI/180;c.clearRect(0,0,1640,650);
 const p=(lng,la)=>{const l=(lng-lon)*rad,f=la*rad;return [cx+R*Math.cos(f)*Math.sin(l),cy-R*(Math.cos(lat)*Math.sin(f)-Math.sin(lat)*Math.cos(f)*Math.cos(l)),Math.sin(lat)*Math.sin(f)+Math.cos(lat)*Math.cos(f)*Math.cos(l)];};
 const g=c.createRadialGradient(cx-85,cy-130,12,cx,cy,R);g.addColorStop(0,'rgba(152,165,180,.13)');g.addColorStop(.65,'rgba(43,54,67,.13)');g.addColorStop(1,'rgba(141,155,173,.22)');c.fillStyle=g;c.beginPath();c.arc(cx,cy,R,0,Math.PI*2);c.fill();
 const line=(coords,front)=>{let pen=false;c.beginPath();for(const v of coords){let q=p(v[0],v[1]);let ok=front?q[2]>=0:q[2]<0;if(ok){if(pen)c.lineTo(q[0],q[1]);else c.moveTo(q[0],q[1]);pen=true;}else pen=false;}c.stroke();};
 c.lineWidth=.9;c.strokeStyle='rgba(154,169,188,.13)';for(const ring of window.globalCountryLines)line(ring,false);
 c.strokeStyle='rgba(169,184,200,.58)';c.lineWidth=1.05;for(const ring of window.globalCountryLines)line(ring,true);
 c.strokeStyle='rgba(137,153,173,.16)';c.lineWidth=.8;
 for(let la=-60;la<=60;la+=30){const arr=[];for(let lo=-180;lo<=180;lo+=3)arr.push([lo,la]);line(arr,true);}
 for(let lo=-180;lo<180;lo+=30){const arr=[];for(let la=-90;la<=90;la+=3)arr.push([lo,la]);line(arr,true);}
 for(const key of ['us','cn']){const alpha=Number(canvas.style.getPropertyValue('--'+key+'-focus')||0);if(alpha<.01)continue;c.fillStyle='rgba(190,205,220,'+(alpha*.35)+')';c.strokeStyle='rgba(221,231,241,'+(alpha*.95)+')';c.lineWidth=1.4;for(const ring of (window.countryFocusGeometry[key]||[])){c.beginPath();let pen=false;for(const pt of ring){const q=p(pt[0],pt[1]);if(q[2]<0){pen=false;continue;}if(pen)c.lineTo(q[0],q[1]);else c.moveTo(q[0],q[1]);pen=true;}c.closePath();c.fill();c.stroke();}}
 c.strokeStyle='rgba(198,211,225,.48)';c.lineWidth=1.25;c.beginPath();c.arc(cx,cy,R,0,2*Math.PI);c.stroke();
 for(const [name,lo,la,key] of [['中国 · 北京',116.4074,39.9042,'--beijing-focus'],['美国 · 纽约',-74.006,40.7128,'--newyork-focus']]){
  const v=p(lo,la),alpha=Number(canvas.style.getPropertyValue(key)||0);if(v[2]<0||alpha<.01)continue;
  c.globalAlpha=alpha;c.fillStyle='#C48798';c.beginPath();c.arc(v[0],v[1],5,0,Math.PI*2);c.fill();c.strokeStyle='#AE687C';c.lineWidth=1.5;c.beginPath();c.arc(v[0],v[1],13,0,Math.PI*2);c.stroke();
  c.globalAlpha=1;
 }
}
